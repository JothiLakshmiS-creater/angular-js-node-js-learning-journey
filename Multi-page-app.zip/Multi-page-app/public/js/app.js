angular.module("myApp", ["ngRoute"]).config(function ($routeProvider) {
  $routeProvider
    .when("/", {
      templateUrl: "views/home.html",
    })
    .when("/contact", {
      templateUrl: "views/contact.html",
    })
    .when("/career", {
      templateUrl: "views/career.html",
    })
    .otherwise({ redirectTo: "/" });
});
