const app = angular.module("myApp", ["ngRoute"]);

app.config(function ($routeProvider) {
  $routeProvider
    .when("/home", {
      templateUrl: "home.html",
    })
    .when("/career", {
      templateUrl: "career.html",
    })
    .when("/contact", {
      templateUrl: "contact.html",
      controller: "ContactCtrl",
    })
    .otherwise({ redirectTo: "/home" });
});
app.controller("ContactCtrl", function ($scope, $http) {
  $scope.formData = {};

  $scope.submitForm = function () {
    $http
      .post("/api/contact", $scope.formData)
      .then(function (response) {
        alert("Message sent successfully!");
        $scope.formData = {}; // reset form
      })
      .catch(function (error) {
        alert("Error sending message.");
        console.error(error);
      });
  };
});
